This is a Quiz App made with swing.External libraries and dependencies have been used for material ui and gradient finish.

INFO--

1--This app supports a login feature
2--adding new question is supported through admin username and password
3--DO NOT Modify or Rename the text files or the app WILL break
4--To run the app from command line Type: "java -jar Quiz_Master.jar" 
5--This app has been created using the NetBeans IDE

Credits to--

For Material Look and Feel--https://vincenzopalazzo.github.io/material-ui-swing/
For Gradient KControls--https://k33ptoo.github.io/KControls/